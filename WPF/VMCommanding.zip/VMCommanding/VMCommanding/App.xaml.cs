﻿using System.Windows;

namespace VMCommanding
{
    public partial class App : Application
    {
    }
}