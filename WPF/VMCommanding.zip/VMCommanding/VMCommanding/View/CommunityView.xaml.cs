﻿using System.Windows.Controls;

namespace VMCommanding.View
{
    public partial class CommunityView : UserControl
    {
        public CommunityView()
        {
            InitializeComponent();
        }
    }
}