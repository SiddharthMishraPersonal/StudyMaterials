﻿using System.Windows.Controls;

namespace VMCommanding.View
{
    public partial class PersonView : UserControl
    {
        public PersonView()
        {
            InitializeComponent();
        }
    }
}