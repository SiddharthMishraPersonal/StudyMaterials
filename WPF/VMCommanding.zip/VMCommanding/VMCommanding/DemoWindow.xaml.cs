﻿using System.Windows;

namespace VMCommanding
{
    public partial class DemoWindow : Window
    {
        public DemoWindow()
        {
            InitializeComponent();
        }
    }
}