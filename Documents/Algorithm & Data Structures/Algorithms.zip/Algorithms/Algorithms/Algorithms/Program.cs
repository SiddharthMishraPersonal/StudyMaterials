﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Algorithms.Sorting;

namespace Algorithms
{
    class Program
    {
        static void Main(string[] args)
        {
            int iterations = 1000000;
            long totalTimeInTicks = 0;
            int sortSpaceSize = 500;

            Random randomizer = new Random((int)(DateTime.Now.Ticks/100000000L));

            CountingSort c= new CountingSort();
            byte[] sortSpace = new byte[sortSpaceSize];
            for (int index = 0; index < sortSpaceSize; index++)
                sortSpace[index] = (byte)randomizer.Next(256);
            for (int i = 0; i < iterations; i++)
            {
                long timeAtStart = DateTime.Now.Ticks;
                byte[] b = c.Sort(sortSpace);
                long timeAtEnd = DateTime.Now.Ticks;

                // Test for validity
                byte lastByte = 0;
                foreach (byte element in b)
                    if (element < lastByte)
                        throw new Exception("Array is not sorted.");
                    else
                        lastByte = element;

                totalTimeInTicks += timeAtEnd - timeAtStart;
            }

            Console.WriteLine();
            Console.WriteLine("Items per iteration: {0}", sortSpaceSize);
            Console.WriteLine("Total running time ({0} iterations): {1} ticks.", iterations, totalTimeInTicks);
            Console.WriteLine("Average iteration time: {0} ticks.", totalTimeInTicks/iterations);
            Console.ReadKey();
        }
    }
}
