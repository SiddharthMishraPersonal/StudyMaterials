﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Algorithms.Sorting
{
    public class CountingSort
    {
        public byte[] Sort(byte[] input)
        {
            int[] index = new int[byte.MaxValue + 1];

            for (int j = 0; j < input.Length; j++)
                index[input[j]]++;

            for (int i = 1; i < index.Length; i++)
                index[i] = index[i] + index[i - 1];

            byte[] output = new byte[input.Length];

            for (int i = input.Length - 1; i >= 0; i--)
            {
                output[index[input[i]] -1] = input[i];
                index[input[i]]--;
            }

            return output;
        }
    }
}
