﻿namespace Algorithms.Tests.Factories
{
    using System;

    public sealed class RandomByteArrayFactory
    {
        private static readonly Random randomByteGenerator = new Random(DateTime.Now.GetHashCode());
        private static readonly int randomizerLimit = byte.MaxValue + 1;

        public static byte[] Generate(int arraySize)
        {
            byte[] array = new byte[arraySize];

            for (int index = 0; index < arraySize; index++)
                array[index] = (byte)randomByteGenerator.Next(randomizerLimit);

            return array;
        }
    }
}
