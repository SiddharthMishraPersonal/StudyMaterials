﻿namespace Algorithms.Tests.Factories
{
    using System;

    public sealed class RandomInt32ArrayFactory
    {
        private static readonly Random randomInt32Generator = new Random(DateTime.Now.GetHashCode());
        private static readonly int randomizerLimit = int.MaxValue;

        public static int[] Generate(int arraySize)
        {
            int[] array = new int[arraySize];

            for (int index = 0; index < arraySize; index++)
                // Note that since we cannot pass a value greater than int.MaxValue to Random,
                // no elements with int.MaxValue will ever be generated.
                array[index] = randomInt32Generator.Next(randomizerLimit);

            return array;
        }
    }
}
