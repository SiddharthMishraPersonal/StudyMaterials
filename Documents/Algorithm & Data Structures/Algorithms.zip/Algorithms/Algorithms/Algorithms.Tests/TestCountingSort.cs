﻿namespace Algorithms.Tests
{
    using MbUnit.Framework;
    using Algorithms.Tests.Factories;
    using Algorithms.Sorting;
    using Algorithms.Tests.Assertions;
    using System.Diagnostics;

    [TestFixture]
    public class TestCountingSort
    {
        [Test]
        public void SortTest()
        {
            int arraySize = 500;
            CountingSort sorter = new CountingSort();

            byte[] sortable = RandomByteArrayFactory.Generate(arraySize);
            byte[] sorted = sorter.Sort(sortable);

            SortedArrayAssert.IsSorted<byte>(sorted, true);
        }

        [Test]
        [TestCategory("Performance", "Slow")]
        public void PerformanceTest()
        {
            CountingSort sorter = new CountingSort();

            int arraySize = 500;
            int iterations = 1000000;

            double expectedAverageDurationInTicks = 300.00;
            double acceptedDeltaForAverageInTicks = 50.00;

            long totalProcessingTime = 0;
            Stopwatch stopwatch = new Stopwatch();

            for (int i = 0; i < iterations; i++)
            {
                byte[] sortable = RandomByteArrayFactory.Generate(arraySize);

                stopwatch.Start();
                byte[] sorted = sorter.Sort(sortable);
                
                stopwatch.Stop();
                SortedArrayAssert.IsSorted<byte>(sorted, true);

                totalProcessingTime += stopwatch.Elapsed.Ticks;
                stopwatch.Reset();
            }

            double averageTime = (double)totalProcessingTime / (double)iterations;
            Assert.AreEqual(expectedAverageDurationInTicks, averageTime, acceptedDeltaForAverageInTicks);
        }
    }
}
