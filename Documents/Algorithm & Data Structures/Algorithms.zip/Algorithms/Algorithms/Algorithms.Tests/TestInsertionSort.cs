﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Algorithms.Tests
{
    using MbUnit.Framework;
    using Algorithms.Tests.Factories;
    using Algorithms.Sorting;
    using Algorithms.Tests.Assertions;
    using System.Diagnostics;

    [TestFixture]
    public class TestInsertionSort
    {
        [Test]
        public void SortTest()
        {
            int arraySize = 500;
            InsertionSort sorter = new InsertionSort();

            int[] sortable = RandomInt32ArrayFactory.Generate(arraySize);
            int[] sorted = sorter.Sort(sortable);

            SortedArrayAssert.IsSorted<int>(sorted, true);
        }
    }
}
