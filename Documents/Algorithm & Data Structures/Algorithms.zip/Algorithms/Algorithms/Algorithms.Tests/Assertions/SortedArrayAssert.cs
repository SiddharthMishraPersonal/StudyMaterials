﻿namespace Algorithms.Tests.Assertions
{
    using System;
    using MbUnit.Core.Exceptions;

    public class SortedArrayAssert
    {
        private const string SortedAssertionFailedMessagePattern =
            "Array is not sorted in {6} order. Element at position {0} is {4} than element at position {1}. ([[{2}]{5}[{3}]] False)";

        public static void IsSorted<T>(T[] array, bool ascending) where T : IComparable<T>
        {
            T lastObject = array[0];
            for (int index = 1; index < array.Length; index++)
            {
                T element = array[index];

                bool elementIsGreaterThanOrEqualToLast = element.CompareTo(lastObject) >= 0;
                bool isValidOrder = (ascending) 
                    ? elementIsGreaterThanOrEqualToLast
                    : !elementIsGreaterThanOrEqualToLast;

                if (!isValidOrder)
                    throw new AssertionException(string.Format(SortedArrayAssert.SortedAssertionFailedMessagePattern,
                        index, index - 1, element, lastObject,
                        (ascending) ? "smaller" : "greater",
                        (ascending) ? ">=" : "<=",
                        (ascending) ? "ascending" : "descending"));
                        


                lastObject = element;
            }
        }
    }
}
